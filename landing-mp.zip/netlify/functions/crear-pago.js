// Crea el pago en Mercado Pago y lleva al comprador a pagar.
// Al terminar, Mercado Pago lo devuelve a /gracias.html de tu sitio.
// La credencial NO va acá: se guarda en Netlify como variable MP_ACCESS_TOKEN.

const TITULO = "EQUIPLANNER - Planificador Semanal Equino";
const PRECIO = 22800;      // en pesos argentinos
const MONEDA = "ARS";

exports.handler = async () => {
  const token = process.env.MP_ACCESS_TOKEN;
  const sitio = (process.env.SITE_URL || process.env.URL || "").replace(/\/$/, "");

  if (!token || !sitio) {
    return pagina(500, "Falta configurar el pago. Avisale al vendedor.");
  }

  try {
    const r = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        items: [{ title: TITULO, quantity: 1, unit_price: PRECIO, currency_id: MONEDA }],
        back_urls: {
          success: sitio + "/gracias.html",
          pending: sitio + "/gracias.html?estado=pendiente",
          failure: sitio + "/gracias.html?estado=fallido"
        },
        auto_return: "approved"
      })
    });
    const d = await r.json();
    if (!r.ok || !d.init_point) {
      console.error("Mercado Pago respondió:", JSON.stringify(d));
      return pagina(502, "No pudimos iniciar el pago. Probá de nuevo en unos minutos.");
    }
    return { statusCode: 302, headers: { Location: d.init_point, "Cache-Control": "no-store" }, body: "" };
  } catch (e) {
    console.error(e);
    return pagina(502, "No pudimos iniciar el pago. Probá de nuevo en unos minutos.");
  }
};

function pagina(codigo, mensaje) {
  return {
    statusCode: codigo,
    headers: { "Content-Type": "text/html; charset=utf-8" },
    body: '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
          '<body style="font:18px system-ui;max-width:480px;margin:15vh auto;padding:0 20px;text-align:center">' +
          "<p>" + mensaje + '</p><p><a href="/">Volver</a></p></body>'
  };
}
